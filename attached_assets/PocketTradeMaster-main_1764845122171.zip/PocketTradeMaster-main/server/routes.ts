import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { fetchCurrentRates, generateHistoricalData, getPayout, FOREX_PAIRS } from "./lib/forexApi";
import { analyzeMarket } from "./lib/technicalAnalysis";
import { addMinutes, setSeconds, setMilliseconds } from "date-fns";

// Track current signals per pair
const activeSignals: Map<string, any> = new Map();

// Get next 5-minute mark
function getNext5MinuteMark(date: Date): Date {
  const ms = 1000 * 60 * 5;
  const nextMark = new Date(Math.ceil((date.getTime() + 1000) / ms) * ms);
  return setSeconds(setMilliseconds(nextMark, 0), 0);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Get available forex pairs
  app.get("/api/pairs", (req, res) => {
    const pairs = FOREX_PAIRS.map(pair => ({
      pair,
      payout: getPayout(pair),
      type: "FOREX" // Not OTC - real standardized forex
    }));
    res.json(pairs);
  });

  // Get current market rates
  app.get("/api/rates", async (req, res) => {
    try {
      const rates = await fetchCurrentRates();
      res.json(rates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch rates" });
    }
  });

  // Generate a new signal for a specific pair
  app.get("/api/signal/:pair", async (req, res) => {
    try {
      const pair = req.params.pair.replace("-", "/");
      
      if (!FOREX_PAIRS.includes(pair)) {
        return res.status(400).json({ error: "Invalid pair" });
      }

      // Fetch current rate
      const rates = await fetchCurrentRates();
      const currentRate = rates.find(r => r.pair === pair);
      
      if (!currentRate) {
        return res.status(500).json({ error: "Could not fetch rate for pair" });
      }

      // Generate historical data for analysis
      const historicalData = generateHistoricalData(currentRate.rate);
      
      // Analyze market with technical indicators
      const analysis = analyzeMarket(historicalData);
      
      // Calculate entry time (next 5-minute mark with at least 2 min prep)
      const now = new Date();
      let entryTime = getNext5MinuteMark(now);
      if (entryTime.getTime() - now.getTime() < 2 * 60 * 1000) {
        entryTime = addMinutes(entryTime, 5);
      }
      const expiryTime = addMinutes(entryTime, 5);

      const signal = {
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        pair,
        type: analysis.direction,
        entryTime: entryTime.toISOString(),
        expiryTime: expiryTime.toISOString(),
        strength: analysis.strength,
        payout: getPayout(pair),
        status: "ACTIVE",
        indicators: analysis.indicators.map(i => i.description),
        confidence: analysis.confidence,
        currentRate: currentRate.rate,
        analysis: {
          rsi: analysis.indicators.find(i => i.name === "RSI")?.value,
          macd: analysis.indicators.find(i => i.name === "MACD")?.value,
          stochastic: analysis.indicators.find(i => i.name === "Stochastic")?.value,
          bollingerPercentB: analysis.indicators.find(i => i.name === "Bollinger")?.value
        }
      };

      // Store active signal
      activeSignals.set(pair, signal);

      // Save to database
      await storage.createSignal({
        pair: signal.pair,
        type: signal.type,
        entryTime: entryTime,
        expiryTime: expiryTime,
        strength: signal.strength,
        payout: signal.payout,
        status: signal.status,
        indicators: signal.indicators,
        rsiValue: signal.analysis.rsi || null,
        macdValue: signal.analysis.macd || null
      });

      res.json(signal);
    } catch (error) {
      console.error("Signal generation error:", error);
      res.status(500).json({ error: "Failed to generate signal" });
    }
  });

  // Get best signal across all pairs
  app.get("/api/signal", async (req, res) => {
    try {
      const rates = await fetchCurrentRates();
      let bestSignal = null;
      let highestStrength = 0;

      for (const rate of rates) {
        const historicalData = generateHistoricalData(rate.rate);
        const analysis = analyzeMarket(historicalData);
        
        if (analysis.direction !== "NEUTRAL" && analysis.strength > highestStrength) {
          highestStrength = analysis.strength;
          
          const now = new Date();
          let entryTime = getNext5MinuteMark(now);
          if (entryTime.getTime() - now.getTime() < 2 * 60 * 1000) {
            entryTime = addMinutes(entryTime, 5);
          }
          const expiryTime = addMinutes(entryTime, 5);

          bestSignal = {
            id: Math.random().toString(36).substr(2, 9).toUpperCase(),
            pair: rate.pair,
            type: analysis.direction,
            entryTime: entryTime.toISOString(),
            expiryTime: expiryTime.toISOString(),
            strength: analysis.strength,
            payout: getPayout(rate.pair),
            status: "ACTIVE",
            indicators: analysis.indicators.map(i => i.description),
            confidence: analysis.confidence,
            currentRate: rate.rate,
            analysis: {
              rsi: analysis.indicators.find(i => i.name === "RSI")?.value,
              macd: analysis.indicators.find(i => i.name === "MACD")?.value,
              stochastic: analysis.indicators.find(i => i.name === "Stochastic")?.value,
              bollingerPercentB: analysis.indicators.find(i => i.name === "Bollinger")?.value
            }
          };
        }
      }

      if (bestSignal) {
        // Save to database
        await storage.createSignal({
          pair: bestSignal.pair,
          type: bestSignal.type,
          entryTime: new Date(bestSignal.entryTime),
          expiryTime: new Date(bestSignal.expiryTime),
          strength: bestSignal.strength,
          payout: bestSignal.payout,
          status: bestSignal.status,
          indicators: bestSignal.indicators,
          rsiValue: bestSignal.analysis.rsi || null,
          macdValue: bestSignal.analysis.macd || null
        });

        res.json(bestSignal);
      } else {
        res.json({ message: "No strong signals at this time", direction: "NEUTRAL" });
      }
    } catch (error) {
      console.error("Signal generation error:", error);
      res.status(500).json({ error: "Failed to generate signal" });
    }
  });

  // Record a trade result (for martingale tracking)
  app.post("/api/trade", async (req, res) => {
    try {
      const { signalId, pair, type, result, martingaleStep } = req.body;
      
      const trade = await storage.createTrade({
        signalId,
        pair,
        type,
        result,
        martingaleStep: martingaleStep || 1,
        entryTime: new Date()
      });

      res.json(trade);
    } catch (error) {
      console.error("Trade recording error:", error);
      res.status(500).json({ error: "Failed to record trade" });
    }
  });

  // Get trade history
  app.get("/api/trades", async (req, res) => {
    try {
      const trades = await storage.getRecentTrades(20);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trades" });
    }
  });

  // Get martingale status
  app.get("/api/martingale", async (req, res) => {
    try {
      const recentTrades = await storage.getRecentTrades(10);
      
      // Find consecutive losses from most recent trades
      let consecutiveLosses = 0;
      let foundWin = false;
      
      for (const trade of recentTrades) {
        if (trade.result === "WON") {
          foundWin = true;
          break; // Stop counting when we hit a win
        } else if (trade.result === "LOST") {
          consecutiveLosses++;
        }
        // Skip PENDING trades
      }

      // If we have 3 consecutive losses, reset after showing warning
      const maxLossesReached = consecutiveLosses >= 3;
      const nextStep = maxLossesReached ? 1 : Math.min(consecutiveLosses + 1, 3);
      const multiplier = maxLossesReached ? 1 : Math.pow(2, consecutiveLosses); // 1x, 2x, 4x

      let message: string;
      if (maxLossesReached) {
        message = "STOP! 3 consecutive losses reached. Take a break, then start fresh with 1x.";
      } else if (consecutiveLosses === 0) {
        message = "Step 1 - Trade 1x your base amount";
      } else if (consecutiveLosses === 1) {
        message = "Step 2 - Recovering: Trade 2x your base amount";
      } else if (consecutiveLosses === 2) {
        message = "Step 3 (FINAL) - Trade 4x your base amount. STOP if this loses!";
      } else {
        message = `Step ${nextStep} - Trade ${multiplier}x your base amount`;
      }

      res.json({
        consecutiveLosses,
        currentStep: nextStep,
        multiplier,
        shouldTrade: !maxLossesReached,
        message
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get martingale status" });
    }
  });

  // Get signal history
  app.get("/api/signals/history", async (req, res) => {
    try {
      const signals = await storage.getRecentSignals(20);
      res.json(signals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch signal history" });
    }
  });

  // Update signal result
  app.patch("/api/signal/:id/result", async (req, res) => {
    try {
      const { id } = req.params;
      const { result } = req.body; // "WON" or "LOST"
      
      const signal = await storage.updateSignalStatus(id, result);
      res.json(signal);
    } catch (error) {
      res.status(500).json({ error: "Failed to update signal" });
    }
  });

  return httpServer;
}
