// Technical Analysis Library for Forex Signals

export interface PriceData {
  open: number;
  high: number;
  low: number;
  close: number;
  timestamp: number;
}

export interface IndicatorResult {
  name: string;
  value: number;
  signal: "BUY" | "SELL" | "NEUTRAL";
  description: string;
}

// Calculate RSI (Relative Strength Index) - Proper Wilder's smoothing
export function calculateRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  // Initial average
  for (let i = 1; i <= period; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) {
      gains += change;
    } else {
      losses += Math.abs(change);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  // Wilder's smoothing for remaining periods
  for (let i = period + 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

// Calculate EMA (Exponential Moving Average)
export function calculateEMA(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1];
  
  const multiplier = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
  }
  
  return ema;
}

// Calculate EMA series for MACD
function calculateEMASeries(prices: number[], period: number): number[] {
  const emas: number[] = [];
  if (prices.length < period) return prices;
  
  const multiplier = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  for (let i = 0; i < period; i++) {
    emas.push(ema);
  }
  
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
    emas.push(ema);
  }
  
  return emas;
}

// Calculate MACD with proper signal line
export function calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9): { macd: number; signal: number; histogram: number } {
  if (prices.length < slowPeriod + signalPeriod) {
    return { macd: 0, signal: 0, histogram: 0 };
  }

  // Calculate EMA series
  const fastEMAs = calculateEMASeries(prices, fastPeriod);
  const slowEMAs = calculateEMASeries(prices, slowPeriod);
  
  // MACD line series
  const macdLine: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    macdLine.push(fastEMAs[i] - slowEMAs[i]);
  }
  
  // Signal line (9-period EMA of MACD line)
  const signalEMAs = calculateEMASeries(macdLine, signalPeriod);
  
  const currentMACD = macdLine[macdLine.length - 1];
  const currentSignal = signalEMAs[signalEMAs.length - 1];
  const histogram = currentMACD - currentSignal;
  
  return {
    macd: currentMACD,
    signal: currentSignal,
    histogram
  };
}

// Calculate Bollinger Bands
export function calculateBollingerBands(prices: number[], period: number = 20, stdDev: number = 2): { upper: number; middle: number; lower: number; percentB: number } {
  if (prices.length < period) {
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    return { upper: avg, middle: avg, lower: avg, percentB: 0.5 };
  }
  
  const slice = prices.slice(-period);
  const middle = slice.reduce((a, b) => a + b, 0) / period;
  
  const squaredDiffs = slice.map(p => Math.pow(p - middle, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / period;
  const std = Math.sqrt(variance);
  
  const upper = middle + (std * stdDev);
  const lower = middle - (std * stdDev);
  
  const currentPrice = prices[prices.length - 1];
  const percentB = (upper - lower) !== 0 ? (currentPrice - lower) / (upper - lower) : 0.5;
  
  return { upper, middle, lower, percentB };
}

// Calculate Stochastic Oscillator with proper %D
export function calculateStochastic(highs: number[], lows: number[], closes: number[], kPeriod: number = 14, dPeriod: number = 3): { k: number; d: number } {
  if (closes.length < kPeriod + dPeriod) return { k: 50, d: 50 };
  
  // Calculate %K series
  const kValues: number[] = [];
  for (let i = kPeriod - 1; i < closes.length; i++) {
    const periodHighs = highs.slice(i - kPeriod + 1, i + 1);
    const periodLows = lows.slice(i - kPeriod + 1, i + 1);
    const currentClose = closes[i];
    
    const highestHigh = Math.max(...periodHighs);
    const lowestLow = Math.min(...periodLows);
    
    const range = highestHigh - lowestLow;
    const k = range !== 0 ? ((currentClose - lowestLow) / range) * 100 : 50;
    kValues.push(k);
  }
  
  // Calculate %D (SMA of %K)
  const recentKValues = kValues.slice(-dPeriod);
  const d = recentKValues.reduce((a, b) => a + b, 0) / dPeriod;
  const k = kValues[kValues.length - 1];
  
  return { 
    k: isNaN(k) ? 50 : Math.max(0, Math.min(100, k)), 
    d: isNaN(d) ? 50 : Math.max(0, Math.min(100, d))
  };
}

// Main signal analysis function
export function analyzeMarket(prices: PriceData[]): {
  direction: "CALL" | "PUT" | "NEUTRAL";
  strength: number;
  indicators: IndicatorResult[];
  confidence: string;
} {
  if (prices.length < 30) {
    return {
      direction: "NEUTRAL",
      strength: 50,
      indicators: [],
      confidence: "INSUFFICIENT DATA"
    };
  }

  const closes = prices.map(p => p.close);
  const highs = prices.map(p => p.high);
  const lows = prices.map(p => p.low);
  
  const indicators: IndicatorResult[] = [];
  let bullishSignals = 0;
  let bearishSignals = 0;
  
  // RSI Analysis
  const rsi = calculateRSI(closes);
  if (rsi < 30) {
    bullishSignals += 2;
    indicators.push({
      name: "RSI",
      value: rsi,
      signal: "BUY",
      description: `RSI Oversold (${rsi.toFixed(1)})`
    });
  } else if (rsi > 70) {
    bearishSignals += 2;
    indicators.push({
      name: "RSI",
      value: rsi,
      signal: "SELL",
      description: `RSI Overbought (${rsi.toFixed(1)})`
    });
  } else if (rsi < 40) {
    bullishSignals += 1;
    indicators.push({
      name: "RSI",
      value: rsi,
      signal: "BUY",
      description: `RSI Bullish Zone (${rsi.toFixed(1)})`
    });
  } else if (rsi > 60) {
    bearishSignals += 1;
    indicators.push({
      name: "RSI",
      value: rsi,
      signal: "SELL",
      description: `RSI Bearish Zone (${rsi.toFixed(1)})`
    });
  }
  
  // MACD Analysis
  const macd = calculateMACD(closes);
  if (macd.histogram > 0 && macd.macd > macd.signal) {
    bullishSignals += 2;
    indicators.push({
      name: "MACD",
      value: macd.histogram,
      signal: "BUY",
      description: "MACD Bullish Crossover"
    });
  } else if (macd.histogram < 0 && macd.macd < macd.signal) {
    bearishSignals += 2;
    indicators.push({
      name: "MACD",
      value: macd.histogram,
      signal: "SELL",
      description: "MACD Bearish Crossover"
    });
  }
  
  // Bollinger Bands Analysis
  const bb = calculateBollingerBands(closes);
  if (bb.percentB < 0.1) {
    bullishSignals += 2;
    indicators.push({
      name: "Bollinger",
      value: bb.percentB,
      signal: "BUY",
      description: "Price at Lower Band (Bounce Expected)"
    });
  } else if (bb.percentB > 0.9) {
    bearishSignals += 2;
    indicators.push({
      name: "Bollinger",
      value: bb.percentB,
      signal: "SELL",
      description: "Price at Upper Band (Reversal Expected)"
    });
  }
  
  // Stochastic Analysis
  const stoch = calculateStochastic(highs, lows, closes);
  if (stoch.k < 20 && stoch.k > stoch.d) {
    bullishSignals += 2;
    indicators.push({
      name: "Stochastic",
      value: stoch.k,
      signal: "BUY",
      description: `Stochastic Oversold Cross (${stoch.k.toFixed(1)})`
    });
  } else if (stoch.k > 80 && stoch.k < stoch.d) {
    bearishSignals += 2;
    indicators.push({
      name: "Stochastic",
      value: stoch.k,
      signal: "SELL",
      description: `Stochastic Overbought Cross (${stoch.k.toFixed(1)})`
    });
  }

  // EMA Trend
  const ema20 = calculateEMA(closes, 20);
  const ema50 = calculateEMA(closes, 50);
  const currentPrice = closes[closes.length - 1];
  
  if (currentPrice > ema20 && ema20 > ema50) {
    bullishSignals += 1;
    indicators.push({
      name: "EMA Trend",
      value: ema20,
      signal: "BUY",
      description: "Price above EMA20 > EMA50 (Uptrend)"
    });
  } else if (currentPrice < ema20 && ema20 < ema50) {
    bearishSignals += 1;
    indicators.push({
      name: "EMA Trend",
      value: ema20,
      signal: "SELL",
      description: "Price below EMA20 < EMA50 (Downtrend)"
    });
  }

  // Calculate overall direction and strength
  const totalSignals = bullishSignals + bearishSignals;
  let direction: "CALL" | "PUT" | "NEUTRAL" = "NEUTRAL";
  let strength = 50;
  let confidence = "LOW";

  if (totalSignals >= 3) {
    if (bullishSignals > bearishSignals + 1) {
      direction = "CALL";
      strength = Math.min(95, 60 + (bullishSignals - bearishSignals) * 8);
      confidence = bullishSignals >= 5 ? "VERY HIGH" : bullishSignals >= 3 ? "HIGH" : "MEDIUM";
    } else if (bearishSignals > bullishSignals + 1) {
      direction = "PUT";
      strength = Math.min(95, 60 + (bearishSignals - bullishSignals) * 8);
      confidence = bearishSignals >= 5 ? "VERY HIGH" : bearishSignals >= 3 ? "HIGH" : "MEDIUM";
    }
  }

  return {
    direction,
    strength,
    indicators,
    confidence
  };
}
