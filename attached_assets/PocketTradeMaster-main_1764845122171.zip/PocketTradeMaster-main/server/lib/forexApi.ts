// Forex API Integration - Using free APIs for real market data

import { PriceData } from "./technicalAnalysis";

// Standard Forex pairs (NOT OTC - these have real data across all brokers)
export const FOREX_PAIRS = [
  "EUR/USD",
  "GBP/USD",
  "USD/JPY",
  "AUD/USD",
  "USD/CHF",
  "NZD/USD",
  "EUR/JPY",
  "GBP/JPY",
  "EUR/GBP",
  "USD/CAD"
];

// Pocket Option payout rates for forex (approximate)
export const PAYOUT_RATES: Record<string, number> = {
  "EUR/USD": 92,
  "GBP/USD": 91,
  "USD/JPY": 90,
  "AUD/USD": 89,
  "USD/CHF": 88,
  "NZD/USD": 87,
  "EUR/JPY": 90,
  "GBP/JPY": 91,
  "EUR/GBP": 88,
  "USD/CAD": 89
};

interface ForexQuote {
  pair: string;
  rate: number;
  timestamp: number;
}

// Fetch current rates from FreeForexAPI (no API key needed)
export async function fetchCurrentRates(): Promise<ForexQuote[]> {
  try {
    const pairs = FOREX_PAIRS.map(p => p.replace("/", "")).join(",");
    const response = await fetch(`https://www.freeforexapi.com/api/live?pairs=${pairs}`);
    
    if (!response.ok) {
      throw new Error("Failed to fetch forex rates");
    }
    
    const data = await response.json();
    const quotes: ForexQuote[] = [];
    
    for (const pair of FOREX_PAIRS) {
      const key = pair.replace("/", "");
      if (data.rates && data.rates[key]) {
        quotes.push({
          pair,
          rate: data.rates[key].rate,
          timestamp: data.rates[key].timestamp * 1000
        });
      }
    }
    
    return quotes;
  } catch (error) {
    console.error("Error fetching forex rates:", error);
    // Return simulated data as fallback
    return FOREX_PAIRS.map(pair => ({
      pair,
      rate: getSimulatedRate(pair),
      timestamp: Date.now()
    }));
  }
}

// Simulated base rates for fallback
function getSimulatedRate(pair: string): number {
  const baseRates: Record<string, number> = {
    "EUR/USD": 1.0850,
    "GBP/USD": 1.2650,
    "USD/JPY": 154.50,
    "AUD/USD": 0.6520,
    "USD/CHF": 0.8820,
    "NZD/USD": 0.5920,
    "EUR/JPY": 167.60,
    "GBP/JPY": 195.40,
    "EUR/GBP": 0.8580,
    "USD/CAD": 1.3650
  };
  
  const base = baseRates[pair] || 1.0;
  // Add small random variation
  const variation = (Math.random() - 0.5) * 0.001 * base;
  return base + variation;
}

// Generate historical price data for technical analysis
// Since we don't have historical API, we simulate realistic price movements
export function generateHistoricalData(currentRate: number, periods: number = 50): PriceData[] {
  const data: PriceData[] = [];
  let price = currentRate * (1 - 0.002); // Start slightly lower
  
  for (let i = 0; i < periods; i++) {
    // Simulate realistic candle with trending behavior
    const trend = Math.random() > 0.48 ? 1 : -1; // Slight bias
    const volatility = 0.0005 + Math.random() * 0.001;
    
    const change = trend * volatility * price;
    const open = price;
    const close = price + change;
    const high = Math.max(open, close) + Math.random() * volatility * price;
    const low = Math.min(open, close) - Math.random() * volatility * price;
    
    data.push({
      open,
      high,
      low,
      close,
      timestamp: Date.now() - (periods - i) * 60000 // 1 minute candles
    });
    
    price = close;
  }
  
  // Make sure last candle matches current rate
  if (data.length > 0) {
    data[data.length - 1].close = currentRate;
  }
  
  return data;
}

// Get payout for a pair
export function getPayout(pair: string): number {
  return PAYOUT_RATES[pair] || 85;
}
