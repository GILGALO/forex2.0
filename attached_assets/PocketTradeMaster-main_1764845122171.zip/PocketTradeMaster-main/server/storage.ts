import { type User, type InsertUser, type Signal, type InsertSignal, type Trade, type InsertTrade, signals, trades, users } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Signals
  createSignal(signal: InsertSignal): Promise<Signal>;
  getSignal(id: string): Promise<Signal | undefined>;
  getRecentSignals(limit: number): Promise<Signal[]>;
  updateSignalStatus(id: string, status: string): Promise<Signal | undefined>;
  
  // Trades
  createTrade(trade: InsertTrade): Promise<Trade>;
  getRecentTrades(limit: number): Promise<Trade[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Signals
  async createSignal(signal: InsertSignal): Promise<Signal> {
    const [newSignal] = await db.insert(signals).values(signal).returning();
    return newSignal;
  }

  async getSignal(id: string): Promise<Signal | undefined> {
    const [signal] = await db.select().from(signals).where(eq(signals.id, id));
    return signal;
  }

  async getRecentSignals(limit: number): Promise<Signal[]> {
    return await db.select().from(signals).orderBy(desc(signals.createdAt)).limit(limit);
  }

  async updateSignalStatus(id: string, status: string): Promise<Signal | undefined> {
    const [updated] = await db.update(signals).set({ status }).where(eq(signals.id, id)).returning();
    return updated;
  }

  // Trades
  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [newTrade] = await db.insert(trades).values(trade).returning();
    return newTrade;
  }

  async getRecentTrades(limit: number): Promise<Trade[]> {
    return await db.select().from(trades).orderBy(desc(trades.createdAt)).limit(limit);
  }
}

export const storage = new DatabaseStorage();
