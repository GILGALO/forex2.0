import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Signals table to track generated signals
export const signals = pgTable("signals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pair: text("pair").notNull(),
  type: text("type").notNull(), // CALL or PUT
  entryTime: timestamp("entry_time").notNull(),
  expiryTime: timestamp("expiry_time").notNull(),
  strength: integer("strength").notNull(),
  payout: integer("payout").notNull(),
  status: text("status").notNull().default("ACTIVE"), // ACTIVE, WON, LOST, PENDING
  indicators: text("indicators").array().notNull(),
  rsiValue: real("rsi_value"),
  macdValue: real("macd_value"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signals).omit({
  id: true,
  createdAt: true,
});

export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signals.$inferSelect;

// Trades table to track user trades for martingale
export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  signalId: varchar("signal_id").references(() => signals.id),
  pair: text("pair").notNull(),
  type: text("type").notNull(), // CALL or PUT
  result: text("result").notNull(), // WON, LOST, PENDING
  martingaleStep: integer("martingale_step").notNull().default(1), // 1, 2, or 3
  entryTime: timestamp("entry_time").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  createdAt: true,
});

export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof trades.$inferSelect;
