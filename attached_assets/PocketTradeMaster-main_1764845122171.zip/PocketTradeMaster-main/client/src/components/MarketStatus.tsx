import { MarketPair } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowUp, ArrowDown, Minus } from "lucide-react";

interface MarketStatusProps {
  markets: MarketPair[];
}

export function MarketStatus({ markets }: MarketStatusProps) {
  return (
    <Card className="h-full glass-panel">
      <CardHeader className="border-b border-white/5 pb-4">
        <CardTitle className="font-display text-lg">OTC MARKET PAYOUTS</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          <div className="p-4 space-y-3">
            {markets.map((market) => (
              <div key={market.pair} className="flex items-center justify-between p-3 rounded-lg bg-background/40 border border-white/5 hover:border-primary/30 transition-all cursor-default group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-xs font-bold text-muted-foreground group-hover:text-foreground transition-colors">
                    {market.pair.substring(0, 3)}
                  </div>
                  <div>
                    <div className="font-bold text-sm">{market.pair}</div>
                    <div className="text-[10px] text-muted-foreground font-mono">OTC MARKET</div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-mono font-bold text-lg text-primary">{market.payout}%</div>
                  <div className="flex items-center justify-end gap-1 text-[10px] text-muted-foreground">
                    {market.trend === "UP" && <ArrowUp className="w-3 h-3 text-primary" />}
                    {market.trend === "DOWN" && <ArrowDown className="w-3 h-3 text-destructive" />}
                    {market.trend === "NEUTRAL" && <Minus className="w-3 h-3" />}
                    <span>TREND</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
