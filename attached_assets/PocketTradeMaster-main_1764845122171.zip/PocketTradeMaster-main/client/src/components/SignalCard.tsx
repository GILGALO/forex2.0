import { motion, AnimatePresence } from "framer-motion";
import { Signal } from "@/lib/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpCircle, ArrowDownCircle, Timer, Clock, Crosshair, BarChart2, Activity } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";

interface SignalCardProps {
  signal: Signal | null;
  timeLeft: number;
  isLoading?: boolean;
}

const formatTime = (dateStr: string) => {
  const date = new Date(dateStr);
  const zonedDate = toZonedTime(date, "Etc/GMT+4");
  return format(zonedDate, "HH:mm:ss");
};

export function SignalCard({ signal, timeLeft, isLoading }: SignalCardProps) {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  if (isLoading || (!signal && timeLeft > 0)) {
    return (
      <Card className="h-full border-primary/20 bg-card/50 backdrop-blur-sm overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
        <CardContent className="h-full flex flex-col items-center justify-center space-y-8 p-6 md:p-12">
          <div className="relative">
            <div className="absolute inset-0 animate-ping opacity-20 rounded-full bg-primary" />
            <div className="relative bg-background border-2 border-primary rounded-full p-6 md:p-8 shadow-[0_0_30px_-5px_hsl(var(--primary))]">
              <Timer className="w-12 h-12 md:w-16 md:h-16 text-primary animate-pulse" />
            </div>
          </div>
          
          <div className="text-center space-y-2">
            <h2 className="text-2xl md:text-3xl font-display font-bold tracking-wider text-primary">
              {isLoading ? "FETCHING REAL DATA" : "ANALYZING MARKETS"}
            </h2>
            <p className="text-sm md:text-base text-muted-foreground font-mono">
              Calculating RSI, MACD, Bollinger Bands, Stochastic...
            </p>
          </div>

          <div className="text-4xl md:text-6xl font-mono font-bold tabular-nums text-foreground tracking-widest">
            {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
          </div>
          
          <div className="w-full max-w-md space-y-2">
            <div className="flex justify-between text-xs font-mono text-muted-foreground">
              <span>NEXT SIGNAL</span>
              <span className="text-primary animate-pulse">LIVE DATA</span>
            </div>
            <Progress value={(1 - timeLeft / 420) * 100} className="h-1 bg-secondary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!signal || signal.type === "NEUTRAL") {
    return (
      <Card className="h-full border-yellow-500/20 bg-card/50 backdrop-blur-sm overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-b from-yellow-500/5 to-transparent pointer-events-none" />
        <CardContent className="h-full flex flex-col items-center justify-center space-y-6 p-6 md:p-12">
          <Activity className="w-16 h-16 text-yellow-500" />
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-display font-bold text-yellow-500">NO STRONG SIGNAL</h2>
            <p className="text-muted-foreground font-mono">Market conditions are neutral. Waiting for clear opportunity...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const isCall = signal.type === "CALL";
  const colorClass = isCall ? "text-primary box-glow-green" : "text-destructive box-glow-red";
  const bgClass = isCall ? "bg-primary/10 border-primary/50" : "bg-destructive/10 border-destructive/50";

  return (
    <AnimatePresence mode="wait">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="h-full"
      >
        <Card className={`h-full border-2 ${bgClass} relative overflow-hidden backdrop-blur-md`}>
          <div className={`absolute inset-0 bg-gradient-to-br ${isCall ? "from-primary/10" : "from-destructive/10"} to-transparent pointer-events-none`} />
          
          <CardHeader className="border-b border-white/5 pb-4 md:pb-6">
            <div className="flex flex-col md:flex-row justify-between items-start gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="font-mono bg-background/50 backdrop-blur">
                    ID: {signal.id}
                  </Badge>
                  <Badge variant="default" className={isCall ? "bg-primary text-primary-foreground" : "bg-destructive text-destructive-foreground"}>
                    {signal.confidence} CONFIDENCE
                  </Badge>
                  <Badge variant="outline" className="font-mono bg-blue-500/20 text-blue-400 border-blue-500/50">
                    REAL FOREX
                  </Badge>
                </div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mt-2">
                  {signal.pair}
                </h2>
                {signal.currentRate && (
                  <div className="text-sm text-muted-foreground font-mono">
                    Current Rate: {signal.currentRate.toFixed(5)}
                  </div>
                )}
              </div>
              <div className="text-left md:text-right w-full md:w-auto flex md:block justify-between items-center bg-background/20 md:bg-transparent p-2 md:p-0 rounded md:rounded-none">
                <div className="text-sm text-muted-foreground font-mono mb-0 md:mb-1">PAYOUT</div>
                <div className="text-2xl md:text-3xl font-bold font-mono text-foreground">{signal.payout}%</div>
              </div>
            </div>
          </CardHeader>

          <CardContent className="pt-6 md:pt-8 space-y-6 md:space-y-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 md:gap-8">
              <div className={`w-full md:flex-1 p-6 rounded-xl border-2 ${isCall ? "border-primary bg-primary/5" : "border-destructive bg-destructive/5"} flex flex-col items-center justify-center gap-4 ${colorClass}`}>
                {isCall ? (
                  <ArrowUpCircle className="w-20 h-20 md:w-24 md:h-24 animate-bounce" />
                ) : (
                  <ArrowDownCircle className="w-20 h-20 md:w-24 md:h-24 animate-bounce" />
                )}
                <span className="text-4xl md:text-5xl font-black tracking-widest">{signal.type}</span>
                <span className="text-xs font-mono opacity-75">ENTER AT START TIME</span>
              </div>
              
              <div className="w-full md:flex-1 space-y-6">
                {/* Times */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-background/30 p-4 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2 text-[10px] md:text-xs text-muted-foreground font-mono mb-1">
                      <Clock className="w-3 h-3" /> START (GMT-4)
                    </div>
                    <div className="text-lg md:text-xl font-bold font-mono">{formatTime(signal.entryTime)}</div>
                  </div>
                  <div className="bg-background/30 p-4 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2 text-[10px] md:text-xs text-muted-foreground font-mono mb-1">
                      <Clock className="w-3 h-3" /> END (GMT-4)
                    </div>
                    <div className="text-lg md:text-xl font-bold font-mono">{formatTime(signal.expiryTime)}</div>
                  </div>
                </div>

                {/* Technicals */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                    <BarChart2 className="w-4 h-4" />
                    TECHNICAL INDICATORS (REAL ANALYSIS)
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {signal.indicators && signal.indicators.map((ind, i) => (
                      <Badge key={i} variant="secondary" className="bg-white/5 hover:bg-white/10 border-white/10 text-xs">
                        {ind}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Strength */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-mono text-muted-foreground">
                    <span className="flex items-center gap-2"><Crosshair className="w-4 h-4" /> SIGNAL STRENGTH</span>
                    <span className="text-foreground font-bold">{signal.strength}%</span>
                  </div>
                  <Progress value={signal.strength} className={`h-2 ${isCall ? "bg-primary/20" : "bg-destructive/20"}`} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}
