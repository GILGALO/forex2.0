import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, TrendingUp, Layers } from "lucide-react";

interface MartingaleTrackerProps {
  consecutiveLosses: number;
  currentStep: number;
  multiplier: number;
  shouldTrade: boolean;
  message: string;
}

export function MartingaleTracker({ consecutiveLosses, currentStep, multiplier, shouldTrade, message }: MartingaleTrackerProps) {
  const getStepColor = (step: number) => {
    if (step === 1) return "bg-primary/20 text-primary border-primary/50";
    if (step === 2) return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50";
    return "bg-destructive/20 text-destructive border-destructive/50";
  };

  return (
    <Card className="glass-panel">
      <CardHeader className="border-b border-white/5 pb-4">
        <CardTitle className="font-display text-lg flex items-center gap-2">
          <Layers className="w-5 h-5 text-primary" />
          MARTINGALE TRACKER
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* Current Step Indicator */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground font-mono">CURRENT STEP</span>
          <Badge className={`${getStepColor(currentStep)} border text-lg px-3 py-1`}>
            {currentStep} / 3
          </Badge>
        </div>

        {/* Step Progression */}
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map((step) => (
            <div
              key={step}
              className={`p-3 rounded-lg border text-center ${
                step < currentStep
                  ? "bg-destructive/20 border-destructive/50"
                  : step === currentStep
                  ? "bg-primary/20 border-primary/50 ring-2 ring-primary/30"
                  : "bg-background/30 border-white/10"
              }`}
            >
              <div className="text-xs text-muted-foreground font-mono mb-1">STEP {step}</div>
              <div className="text-lg font-bold">{Math.pow(2, step - 1)}x</div>
              <div className="text-[10px] text-muted-foreground">
                {step < currentStep ? "LOSS" : step === currentStep ? "NEXT" : "PENDING"}
              </div>
            </div>
          ))}
        </div>

        {/* Status Message */}
        <div className={`p-3 rounded-lg flex items-center gap-3 ${
          shouldTrade ? "bg-primary/10 border border-primary/30" : "bg-destructive/10 border border-destructive/30"
        }`}>
          {shouldTrade ? (
            <CheckCircle className="w-5 h-5 text-primary shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0" />
          )}
          <div className="text-sm font-mono">{message}</div>
        </div>

        {/* Trade Multiplier */}
        <div className="bg-background/30 p-4 rounded-lg border border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground font-mono">NEXT TRADE SIZE</span>
            </div>
            <span className="text-2xl font-bold font-mono text-primary">{multiplier}x</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {consecutiveLosses > 0 
              ? `Recovering from ${consecutiveLosses} consecutive loss${consecutiveLosses > 1 ? 'es' : ''}`
              : "Starting fresh - trade base amount"
            }
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
