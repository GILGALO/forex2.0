import { Signal } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { TrendingUp, TrendingDown } from "lucide-react";

interface SignalHistoryProps {
  history: Signal[];
}

export function SignalHistory({ history }: SignalHistoryProps) {
  return (
    <Card className="h-full glass-panel">
      <CardHeader className="border-b border-white/5">
        <CardTitle className="font-display text-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          RECENT SIGNALS
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent border-white/5">
              <TableHead className="text-xs font-mono">TIME</TableHead>
              <TableHead className="text-xs font-mono">PAIR</TableHead>
              <TableHead className="text-xs font-mono">TYPE</TableHead>
              <TableHead className="text-xs font-mono text-right">RESULT</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.map((signal) => (
              <TableRow key={signal.id} className="hover:bg-white/5 border-white/5 transition-colors">
                <TableCell className="font-mono text-xs text-muted-foreground">
                  {format(signal.entryTime, "HH:mm")}
                </TableCell>
                <TableCell className="font-bold text-sm">{signal.pair}</TableCell>
                <TableCell>
                  <Badge 
                    variant="outline" 
                    className={`font-mono text-[10px] border-0 ${
                      signal.type === "CALL" 
                        ? "bg-primary/20 text-primary" 
                        : "bg-destructive/20 text-destructive"
                    }`}
                  >
                    {signal.type === "CALL" ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                    {signal.type}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <span className={`font-bold font-mono ${
                    signal.status === "WON" ? "text-primary text-glow" : "text-destructive"
                  }`}>
                    {signal.status}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
