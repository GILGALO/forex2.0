import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";
import { Signal, recordTrade } from "@/lib/api";

interface TradeRecorderProps {
  signal: Signal | null;
  martingaleStep: number;
  onTradeRecorded: () => void;
}

export function TradeRecorder({ signal, martingaleStep, onTradeRecorded }: TradeRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);

  const handleRecordResult = async (result: "WON" | "LOST") => {
    if (!signal) return;
    
    setIsRecording(true);
    try {
      await recordTrade({
        signalId: signal.id,
        pair: signal.pair,
        type: signal.type,
        result,
        martingaleStep
      });
      onTradeRecorded();
    } catch (error) {
      console.error("Failed to record trade:", error);
    } finally {
      setIsRecording(false);
    }
  };

  if (!signal || signal.type === "NEUTRAL") return null;

  return (
    <Card className="glass-panel">
      <CardHeader className="border-b border-white/5 pb-4">
        <CardTitle className="font-display text-lg">RECORD TRADE RESULT</CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <p className="text-sm text-muted-foreground mb-4 font-mono">
          After your trade expires, record the result to track your martingale progress.
        </p>
        <div className="grid grid-cols-2 gap-4">
          <Button
            onClick={() => handleRecordResult("WON")}
            disabled={isRecording}
            className="bg-primary hover:bg-primary/80 text-primary-foreground h-16 text-lg font-bold gap-2"
          >
            {isRecording ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
            I WON
          </Button>
          <Button
            onClick={() => handleRecordResult("LOST")}
            disabled={isRecording}
            variant="destructive"
            className="h-16 text-lg font-bold gap-2"
          >
            {isRecording ? <Loader2 className="w-5 h-5 animate-spin" /> : <XCircle className="w-5 h-5" />}
            I LOST
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
