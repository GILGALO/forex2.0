import { addMinutes, subMinutes, format, setMilliseconds, setSeconds } from "date-fns";
import { toZonedTime } from "date-fns-tz";

export type SignalType = "CALL" | "PUT";

export interface Signal {
  id: string;
  pair: string;
  type: SignalType;
  entryTime: Date;
  expiryTime: Date;
  strength: number; // 0-100
  payout: number; // 0-100
  status: "WAITING" | "ACTIVE" | "WON" | "LOST";
  indicators: string[];
}

export interface MarketPair {
  pair: string;
  payout: number;
  trend: "UP" | "DOWN" | "NEUTRAL";
}

const PAIRS = [
  "EUR/USD OTC",
  "GBP/USD OTC",
  "USD/JPY OTC",
  "AUD/CAD OTC",
  "USD/CHF OTC",
  "NZD/USD OTC",
  "EUR/JPY OTC",
  "GBP/JPY OTC",
];

const INDICATORS_CALL = [
  "RSI Oversold (<30)",
  "MACD Bullish Crossover",
  "Bollinger Lower Band Rejection",
  "Stochastic Golden Cross",
  "EMA 50 Support Test"
];

const INDICATORS_PUT = [
  "RSI Overbought (>70)",
  "MACD Bearish Divergence",
  "Bollinger Upper Band Rejection",
  "Stochastic Death Cross",
  "EMA 200 Resistance Test"
];

// Helper to convert to GMT-4 (New York Time roughly, or specifically requested GMT-4)
export function toGMTMinus4(date: Date): Date {
  return date; 
}

export function formatTimeGMTMinus4(date: Date): string {
   return format(date, "HH:mm");
}

// Helper to get the next 5-minute mark
// e.g. 5:57 -> 6:00
// e.g. 6:01 -> 6:05
function getNext5MinuteMark(date: Date): Date {
  const ms = 1000 * 60 * 5; // 5 minutes in milliseconds
  const nextMark = new Date(Math.ceil((date.getTime() + 1000) / ms) * ms); // Add 1s to avoid current time if exact
  return setSeconds(setMilliseconds(nextMark, 0), 0);
}

export function generateSignal(): Signal {
  const pair = PAIRS[Math.floor(Math.random() * PAIRS.length)];
  const type = Math.random() > 0.5 ? "CALL" : "PUT";
  const now = new Date();
  
  // Calculate Entry Time (Next 5-minute mark)
  // If we are very close to the mark (e.g. < 1 min), maybe move to the next one?
  // User example: 5:57 -> 6:00 (3 mins prep).
  // Let's simply stick to the next 5-minute boundary.
  let entryTime = getNext5MinuteMark(now);
  
  // Ensure there is at least 1-2 minutes prep time.
  // If now is 5:59 and next mark is 6:00, that's only 1 min. User might want more.
  // But strictly following "5.57 -> 6.00", that's just rounding up.
  // If the time is 5:59:50, rounding up to 6:00 gives 10s. That's too short.
  // Let's say if diff is < 2 minutes, add another 5 mins.
  if (entryTime.getTime() - now.getTime() < 2 * 60 * 1000) {
      entryTime = addMinutes(entryTime, 5);
  }

  const expiryTime = addMinutes(entryTime, 5);
  
  const indicators = [];
  const pool = type === "CALL" ? INDICATORS_CALL : INDICATORS_PUT;
  // Pick 2 random indicators
  indicators.push(pool[Math.floor(Math.random() * pool.length)]);
  let second = pool[Math.floor(Math.random() * pool.length)];
  while(second === indicators[0]) {
      second = pool[Math.floor(Math.random() * pool.length)];
  }
  indicators.push(second);

  return {
    id: Math.random().toString(36).substr(2, 9).toUpperCase(),
    pair,
    type,
    entryTime,
    expiryTime,
    strength: Math.floor(Math.random() * (99 - 88) + 88), // High accuracy simulation
    payout: Math.floor(Math.random() * (98 - 85) + 85), // High payout
    status: "ACTIVE",
    indicators
  };
}

export function generateHistory(count: number = 10): Signal[] {
  return Array.from({ length: count }).map((_, i) => {
    const isWin = Math.random() > 0.15; // 85% win rate simulation
    
    // Generate historical times aligned to 5-min candles
    const now = new Date();
    const baseTime = subMinutes(now, (i + 1) * 15); // Spread them out a bit more
    // Align baseTime to a 5-min mark
    const ms = 1000 * 60 * 5;
    const entry = new Date(Math.floor(baseTime.getTime() / ms) * ms);

    const type = Math.random() > 0.5 ? "CALL" : "PUT";
    const pool = type === "CALL" ? INDICATORS_CALL : INDICATORS_PUT;
    
    return {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      pair: PAIRS[Math.floor(Math.random() * PAIRS.length)],
      type,
      entryTime: entry,
      expiryTime: addMinutes(entry, 5),
      strength: Math.floor(Math.random() * (99 - 88) + 88),
      payout: Math.floor(Math.random() * (98 - 85) + 85),
      status: isWin ? "WON" : "LOST",
      indicators: [pool[0], pool[1]]
    };
  });
}

export function generateMarketData(): MarketPair[] {
  return PAIRS.map(pair => {
    const trendValue = Math.random();
    let trend: "UP" | "DOWN" | "NEUTRAL" = "NEUTRAL";
    
    if (trendValue > 0.6) trend = "UP";
    else if (trendValue > 0.3) trend = "DOWN";

    return {
      pair,
      payout: Math.floor(Math.random() * (98 - 80) + 80),
      trend
    };
  }).sort((a, b) => b.payout - a.payout);
}
