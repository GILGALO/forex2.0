// API client for forex signals

export interface Signal {
  id: string;
  pair: string;
  type: "CALL" | "PUT" | "NEUTRAL";
  entryTime: string;
  expiryTime: string;
  strength: number;
  payout: number;
  status: string;
  indicators: string[];
  confidence: string;
  currentRate: number;
  analysis: {
    rsi?: number;
    macd?: number;
    stochastic?: number;
    bollingerPercentB?: number;
  };
}

export interface MarketPair {
  pair: string;
  payout: number;
  type: string;
}

export interface ForexRate {
  pair: string;
  rate: number;
  timestamp: number;
}

export interface MartingaleStatus {
  consecutiveLosses: number;
  currentStep: number;
  multiplier: number;
  shouldTrade: boolean;
  message: string;
}

export interface Trade {
  id: string;
  signalId: string;
  pair: string;
  type: string;
  result: string;
  martingaleStep: number;
  entryTime: string;
}

// Fetch available forex pairs
export async function fetchPairs(): Promise<MarketPair[]> {
  const response = await fetch('/api/pairs');
  if (!response.ok) throw new Error('Failed to fetch pairs');
  return response.json();
}

// Fetch current rates
export async function fetchRates(): Promise<ForexRate[]> {
  const response = await fetch('/api/rates');
  if (!response.ok) throw new Error('Failed to fetch rates');
  return response.json();
}

// Get best signal across all pairs
export async function fetchBestSignal(): Promise<Signal> {
  const response = await fetch('/api/signal');
  if (!response.ok) throw new Error('Failed to fetch signal');
  return response.json();
}

// Get signal for specific pair
export async function fetchSignalForPair(pair: string): Promise<Signal> {
  const formattedPair = pair.replace('/', '-');
  const response = await fetch(`/api/signal/${formattedPair}`);
  if (!response.ok) throw new Error('Failed to fetch signal');
  return response.json();
}

// Record trade result
export async function recordTrade(trade: {
  signalId: string;
  pair: string;
  type: string;
  result: string;
  martingaleStep: number;
}): Promise<Trade> {
  const response = await fetch('/api/trade', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(trade)
  });
  if (!response.ok) throw new Error('Failed to record trade');
  return response.json();
}

// Get martingale status
export async function fetchMartingaleStatus(): Promise<MartingaleStatus> {
  const response = await fetch('/api/martingale');
  if (!response.ok) throw new Error('Failed to fetch martingale status');
  return response.json();
}

// Get trade history
export async function fetchTradeHistory(): Promise<Trade[]> {
  const response = await fetch('/api/trades');
  if (!response.ok) throw new Error('Failed to fetch trades');
  return response.json();
}

// Update signal result
export async function updateSignalResult(signalId: string, result: 'WON' | 'LOST'): Promise<Signal> {
  const response = await fetch(`/api/signal/${signalId}/result`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ result })
  });
  if (!response.ok) throw new Error('Failed to update signal');
  return response.json();
}
