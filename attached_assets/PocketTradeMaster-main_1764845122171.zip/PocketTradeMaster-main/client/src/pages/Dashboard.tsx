import { useEffect, useState, useCallback } from "react";
import { SignalCard } from "@/components/SignalCard";
import { MartingaleTracker } from "@/components/MartingaleTracker";
import { TradeRecorder } from "@/components/TradeRecorder";
import { 
  Signal, 
  MartingaleStatus, 
  MarketPair,
  fetchBestSignal, 
  fetchMartingaleStatus, 
  fetchPairs,
  fetchRates
} from "@/lib/api";
import { Activity, SignalHigh, Globe, RefreshCw, Info, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import generatedImage from '@assets/generated_images/dark_cyberpunk_trading_background_with_neon_data_lines.png';

const CYCLE_TIME = 7 * 60; // 7 minutes in seconds

export default function Dashboard() {
  const [timeLeft, setTimeLeft] = useState(CYCLE_TIME);
  const [currentSignal, setCurrentSignal] = useState<Signal | null>(null);
  const [martingale, setMartingale] = useState<MartingaleStatus>({
    consecutiveLosses: 0,
    currentStep: 1,
    multiplier: 1,
    shouldTrade: true,
    message: "Step 1 - Trade 1x your base amount"
  });
  const [pairs, setPairs] = useState<MarketPair[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch initial data
  useEffect(() => {
    fetchPairs().then(setPairs).catch(console.error);
    fetchMartingaleStatus().then(setMartingale).catch(console.error);
  }, []);

  // Fetch new signal
  const handleFetchSignal = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const signal = await fetchBestSignal();
      setCurrentSignal(signal);
    } catch (err) {
      setError("Failed to fetch signal. Check your connection.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Timer Logic
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleFetchSignal();
          return CYCLE_TIME; 
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [handleFetchSignal]);

  // Manual refresh
  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await handleFetchSignal();
      await fetchMartingaleStatus().then(setMartingale);
    } finally {
      setIsRefreshing(false);
    }
  };

  // After recording a trade
  const handleTradeRecorded = async () => {
    await fetchMartingaleStatus().then(setMartingale);
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6 relative overflow-x-hidden font-sans">
      {/* Background Image Overlay */}
      <div 
        className="fixed inset-0 z-0 opacity-40 pointer-events-none bg-cover bg-center"
        style={{ backgroundImage: `url(${generatedImage})` }}
      />
      <div className="fixed inset-0 z-0 bg-background/80 pointer-events-none backdrop-blur-[2px]" />

      <div className="relative z-10 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between p-4 rounded-xl glass-panel gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/50 flex items-center justify-center box-glow-green shrink-0">
              <SignalHigh className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-display font-bold tracking-wider text-white">POCKET<span className="text-primary">BOT</span> FOREX</h1>
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                REAL FOREX DATA - NOT OTC
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between w-full md:w-auto gap-4">
             <div className="text-right mr-4 md:mr-0">
               <div className="text-xs text-muted-foreground font-mono flex items-center justify-end gap-1">
                 SERVER TIME <Info className="w-3 h-3" />
               </div>
               <div className="text-lg md:text-xl font-bold text-foreground font-mono">GMT-4</div>
             </div>

             <Button 
               variant="outline" 
               onClick={handleManualRefresh}
               disabled={isRefreshing || isLoading}
               className="border-primary/50 text-primary hover:bg-primary/20 gap-2"
               data-testid="button-refresh"
             >
               <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
               <span className="hidden md:inline">GET SIGNAL NOW</span>
               <span className="md:hidden">SIGNAL</span>
             </Button>
          </div>
        </header>

        {/* Error Alert */}
        {error && (
          <div className="bg-destructive/10 border border-destructive/50 text-destructive p-4 rounded-xl flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span className="font-mono text-sm">{error}</span>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column - Main Signal (8 cols) */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            <div className="min-h-[400px]">
              <SignalCard signal={currentSignal} timeLeft={timeLeft} isLoading={isLoading} />
            </div>
            
            {/* Trade Recorder */}
            <TradeRecorder 
              signal={currentSignal} 
              martingaleStep={martingale.currentStep}
              onTradeRecorded={handleTradeRecorded}
            />
            
            {/* Stats / Info Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="glass-panel p-4 rounded-xl flex items-center gap-4">
                <div className="p-3 rounded-full bg-blue-500/10 text-blue-400">
                  <Activity className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-mono">DATA SOURCE</div>
                  <div className="text-lg font-bold font-display">REAL FOREX</div>
                </div>
              </div>
              <div className="glass-panel p-4 rounded-xl flex items-center gap-4">
                <div className="p-3 rounded-full bg-purple-500/10 text-purple-400">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-mono">PAIRS AVAILABLE</div>
                  <div className="text-lg font-bold font-display">{pairs.length} FOREX</div>
                </div>
              </div>
              <div className="glass-panel p-4 rounded-xl flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10 text-primary">
                  <SignalHigh className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-mono">ANALYSIS</div>
                  <div className="text-lg font-bold font-display">RSI+MACD+BB</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Sidebar (4 cols) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            {/* Martingale Tracker */}
            <MartingaleTracker {...martingale} />

            {/* Available Pairs */}
            <Card className="glass-panel flex-1">
              <CardHeader className="border-b border-white/5 pb-4">
                <CardTitle className="font-display text-lg">FOREX PAIRS (REAL DATA)</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[250px]">
                  <div className="p-4 space-y-2">
                    {pairs.map((pair) => (
                      <div 
                        key={pair.pair} 
                        className="flex items-center justify-between p-3 rounded-lg bg-background/40 border border-white/5 hover:border-primary/30 transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-xs font-bold text-muted-foreground">
                            {pair.pair.substring(0, 3)}
                          </div>
                          <div>
                            <div className="font-bold text-sm">{pair.pair}</div>
                            <div className="text-[10px] text-muted-foreground font-mono">{pair.type}</div>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                          {pair.payout}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Info Box */}
            <Card className="glass-panel">
              <CardContent className="p-4">
                <div className="text-xs text-muted-foreground font-mono space-y-2">
                  <p><strong className="text-primary">REAL FOREX:</strong> Standard currency pairs, same across all brokers.</p>
                  <p><strong className="text-primary">ANALYSIS:</strong> RSI, MACD, Bollinger Bands, Stochastic, EMA calculated from live rates.</p>
                  <p><strong className="text-primary">MARTINGALE:</strong> 3-step recovery system. Stop after 3 consecutive losses.</p>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      </div>
    </div>
  );
}
